package Learning1;

public interface AnimalInterface {
    public  void move();
    public  void eat();
}
