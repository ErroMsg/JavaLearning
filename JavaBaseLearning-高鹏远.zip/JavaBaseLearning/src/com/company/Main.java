package com.company;

import Learning2.MainFunction2;

public class Main {
    public static void main(String[] args) {

        System.out.println("Start");

/*
*************************************************************/
        //基本数据类型大小
        //MainFunction1.printBaseTypeSize();
        //
        //MainFunction1.practise();

        //数组
        //MainFunction1.ArrayTest();

        //类
        //MainFunction1.classTest();

/*
*************************************************************/

        //
        //MainFunction2.printArgsFunction("A","B","C","D","CCCC");

        //接口学习
        //MainFunction2.interfaceTestCode();

        //clone
        /*try{
            MainFunction2.cloneTest();
        }
        catch (CloneNotSupportedException e) {
            System.out.println("Clone Not Support!!!");
        }*/

        //lamda
        //MainFunction2.LamdaTest();

        //String
        MainFunction2.StringTest();

        System.out.println("End");

    }

}
